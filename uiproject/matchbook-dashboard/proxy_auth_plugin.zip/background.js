
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "geo.iproyal.com",
                port: parseInt(12321)
            },
            bypassList: ["localhost"]
        }
    };
    chrome.proxy.settings.set({ value: config, scope: "regular" }, function(){});
    
    function cb(details) {
        return {
            authCredentials: {
                username: "jbg953Ex5efbFWOi",
                password: "sEtTrh7kMRPvYD5D_country-us_session-fWWCViFT_lifetime-20m_streaming-1_skipispstatic-1"
            }
        };
    }
    chrome.webRequest.onAuthRequired.addListener(cb, {urls: ["<all_urls>"]}, ["blocking"]);
    